document.querySelector("#myButton").onclick = function () {
    const button = document.querySelector("#myButton");
    button.innerText = "I am currently learning JavaScript"
}